# Payroll Calculator App

## Setup & Run
```
npm install
npm start
```
Open: http://localhost:3000

## Features
- Input: Employee Name, EID, Designation, Basic Pay
- Calculates: HRA (40%), DA (20%), TA (10%), Gross Pay
- Deductions: PF (12% of Basic), Tax (10% of Gross)
- Output: Net Pay with styled result table
