const express = require('express');
const path = require('path');
const app = express();

app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// GET - Show input form
app.get('/', (req, res) => {
  res.render('form');
});

// POST - Calculate payroll
app.post('/calculate', (req, res) => {
  const { empName, eid, designation, basicPay } = req.body;
  const basic = parseFloat(basicPay);

  const hra     = basic * 0.40;   // 40% of Basic
  const da      = basic * 0.20;   // 20% of Basic
  const ta      = basic * 0.10;   // 10% of Basic
  const grossPay = basic + hra + da + ta;

  const pf      = basic * 0.12;   // 12% of Basic
  const tax     = grossPay * 0.10; // 10% of Gross
  const netPay  = grossPay - pf - tax;

  res.render('result', {
    empName,
    eid,
    designation,
    basicPay: basic.toFixed(2),
    hra: hra.toFixed(2),
    da: da.toFixed(2),
    ta: ta.toFixed(2),
    grossPay: grossPay.toFixed(2),
    pf: pf.toFixed(2),
    tax: tax.toFixed(2),
    netPay: netPay.toFixed(2)
  });
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Payroll app running at http://localhost:${PORT}`);
});
