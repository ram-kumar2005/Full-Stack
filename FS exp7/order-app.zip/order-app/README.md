# Online Order Application

## Setup & Run
```
npm install
npm start
```
Open: http://localhost:3001

## Routes
- GET  /        → List all products
- POST /cart    → Add item to cart
- GET  /cart    → View cart
- POST /remove  → Remove item from cart
- POST /order   → Place order
- GET  /orders  → View all past orders
