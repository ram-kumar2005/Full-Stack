const express = require('express');
const path = require('path');
const app = express();

app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// --- In-memory data store ---
const products = [
  { id: 1, name: 'Laptop',      price: 55000, image: '💻' },
  { id: 2, name: 'Smartphone',  price: 18000, image: '📱' },
  { id: 3, name: 'Headphones',  price: 3500,  image: '🎧' },
  { id: 4, name: 'Tablet',      price: 22000, image: '📟' },
  { id: 5, name: 'Smartwatch',  price: 8000,  image: '⌚' },
];

let cart = [];      // { id, name, price, qty }
let orders = [];    // confirmed orders

// ---------------------------------------------------------
// GET /  →  List all items
// ---------------------------------------------------------
app.get('/', (req, res) => {
  res.render('items', { products, message: null });
});

// ---------------------------------------------------------
// POST /cart  →  Add item to cart
// ---------------------------------------------------------
app.post('/cart', (req, res) => {
  const productId = parseInt(req.body.productId);
  const qty       = parseInt(req.body.qty) || 1;
  const product   = products.find(p => p.id === productId);

  if (product) {
    const existing = cart.find(c => c.id === productId);
    if (existing) {
      existing.qty += qty;
    } else {
      cart.push({ ...product, qty });
    }
  }
  res.redirect('/cart');
});

// ---------------------------------------------------------
// GET /cart  →  View cart
// ---------------------------------------------------------
app.get('/cart', (req, res) => {
  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  res.render('cart', { cart, total });
});

// ---------------------------------------------------------
// POST /remove  →  Remove item from cart
// ---------------------------------------------------------
app.post('/remove', (req, res) => {
  const productId = parseInt(req.body.productId);
  cart = cart.filter(c => c.id !== productId);
  res.redirect('/cart');
});

// ---------------------------------------------------------
// POST /order  →  Place order
// ---------------------------------------------------------
app.post('/order', (req, res) => {
  if (cart.length === 0) {
    return res.redirect('/cart');
  }
  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const order = {
    id: orders.length + 1,
    items: [...cart],
    total,
    date: new Date().toLocaleString()
  };
  orders.push(order);
  cart = [];   // clear cart after placing order
  res.render('order', { order });
});

// ---------------------------------------------------------
// GET /orders  →  View all past orders
// ---------------------------------------------------------
app.get('/orders', (req, res) => {
  res.render('orders', { orders });
});

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Order app running at http://localhost:${PORT}`);
});
